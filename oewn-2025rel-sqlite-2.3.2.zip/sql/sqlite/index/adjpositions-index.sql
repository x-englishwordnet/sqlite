CREATE UNIQUE INDEX `pk_adjpositions` ON `adjpositions` (`positionid`);
