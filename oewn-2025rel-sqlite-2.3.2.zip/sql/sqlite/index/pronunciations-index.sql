CREATE UNIQUE INDEX `pk_pronunciations` ON `pronunciations` (`pronunciationid`);
CREATE UNIQUE INDEX `uk_pronunciations_pronunciation` ON `pronunciations` (`pronunciation`);
