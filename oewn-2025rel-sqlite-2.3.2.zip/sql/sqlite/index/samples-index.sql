CREATE UNIQUE INDEX `pk_samples` ON `samples` (`synsetid`,`sampleid`);
CREATE INDEX `k_samples_synsetid` ON `samples` (`synsetid`);
CREATE INDEX `k_samples_luid` ON `samples` (`luid`);
CREATE INDEX `k_samples_wordid` ON `samples` (`wordid`);
