CREATE UNIQUE INDEX `pk_relations` ON `relations` (`relationid`);
CREATE UNIQUE INDEX `uk_relations_relation` ON `relations` (`relation`);
