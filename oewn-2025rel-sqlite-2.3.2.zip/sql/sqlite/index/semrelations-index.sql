CREATE UNIQUE INDEX `pk_semrelations` ON `semrelations` (`synset1id`,`synset2id`,`relationid`);
CREATE INDEX `k_semrelations_relationid` ON `semrelations` (`relationid`);
CREATE INDEX `k_semrelations_synset1id` ON `semrelations` (`synset1id`);
CREATE INDEX `k_semrelations_synset2id` ON `semrelations` (`synset2id`);
