CREATE UNIQUE INDEX `pk_ilis` ON `ilis` (`synsetid`);
