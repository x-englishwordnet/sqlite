CREATE TABLE `vframes` (
`frameid` INT NOT NULL,
`frame` VARCHAR(50) NOT NULL
)
;
