CREATE UNIQUE INDEX `pk_senses` ON `senses` (`senseid`);
CREATE UNIQUE INDEX `uk_senses_sensekey` ON `senses` (`sensekey`);
CREATE UNIQUE INDEX `uk_senses_luid_sensekey` ON `senses` (`luid`,`sensekey`);
CREATE UNIQUE INDEX `uk_senses_luid_synsetid` ON `senses` (`luid`,`synsetid`);
CREATE INDEX `k_senses_luid` ON `senses` (`luid`);
CREATE INDEX `k_senses_wordid` ON `senses` (`wordid`);
CREATE INDEX `k_senses_casedwordid` ON `senses` (`casedwordid`);
CREATE INDEX `k_senses_synsetid` ON `senses` (`synsetid`);
