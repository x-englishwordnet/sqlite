CREATE TABLE `synsets` (
`synsetid` INT NOT NULL,
`posid` CHARACTER (1) CHECK( `posid` IN ('n','v','a','r','s') ) NOT NULL,
`domainid` INT NOT NULL,
`definition` MEDIUMTEXT NOT NULL
)
;
