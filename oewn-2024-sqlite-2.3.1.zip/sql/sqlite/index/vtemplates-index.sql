CREATE UNIQUE INDEX `pk_vtemplates` ON `vtemplates` (`templateid`);
CREATE UNIQUE INDEX `uk_vtemplates_template` ON `vtemplates` (`template`);
