CREATE UNIQUE INDEX `pk_usages` ON `usages` (`synsetid`,`usageid`);
CREATE INDEX `k_usages_synsetid` ON `usages` (`synsetid`);
CREATE INDEX `k_usages_luid` ON `usages` (`luid`);
CREATE INDEX `k_usages_wordid` ON `usages` (`wordid`);
