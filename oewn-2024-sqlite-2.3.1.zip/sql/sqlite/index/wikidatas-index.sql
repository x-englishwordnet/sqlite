CREATE UNIQUE INDEX `pk_wikidatas` ON `wikidatas` (`synsetid`);
