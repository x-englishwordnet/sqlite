CREATE TABLE `lexes_morphs` (
`luid` INT NOT NULL,
`wordid` INT NOT NULL,
`posid` CHARACTER (1) CHECK( `posid` IN ('n','v','a','r','s') ) NOT NULL,
`morphid` INT NOT NULL
);
