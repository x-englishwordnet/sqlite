CREATE TABLE `wikidatas` (
`wikidata` VARCHAR(12) NOT NULL,
`synsetid` INT NOT NULL
)
;
