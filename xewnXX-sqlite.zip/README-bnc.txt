This includes
- the BNC data

see http://ucrel.lancs.ac.uk/bncfreq/flists.html
