This includes
- the core WordNet 3.0 database.
- the 2.0-3.0 sensemap
- the 2.1-3.0 sensemap 
- the computed 2.0-3.0 sensemap 
- the XWordnet 2.0-1.1 database with references do synsets mapped to 3.0 references (thanks to 2.0-3.0 sensemap)
- the VerbNet 2.3 database mapped to WordNet 3.0 references
