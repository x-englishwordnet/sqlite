This includes
- the core English WordNet database.

PWN: https://wordnet.princeton.edu/
EWN: https://github.com/globalwordnet/english-wordnet
