This includes
- the core Open English WordNet database.

PWN:  https://wordnet.princeton.edu/
OEWN: https://github.com/globalwordnet/english-wordnet
