This includes
- the core WordNet 3.0 database.

