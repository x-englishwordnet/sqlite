This includes
- the XWordnet 2.0-1.1 database with references do synsets mapped to 3.0 references (thanks to 2.0-3.0 sensemap)

