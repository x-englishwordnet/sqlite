This includes
- the PredicateMatrix 1.1 database http://adimen.si.ehu.es/web/modules/pubdlcnt/pubdlcnt.php?file=http://adimen.si.ehu.es/web/files/PredicateMatrix/PredicateMatrix.v1.1.tar.gz&nid=24

