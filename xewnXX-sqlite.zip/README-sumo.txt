Please refer to http://www.ontologyportal.org/

SUMO is free and owned by the IEEE. 
The ontologies that extend SUMO are available under GNU General Public License.
Adam Pease is the Technical Editor of SUMO.

The current data was taken from the CVS (2009 May 4):
Please refer to http://sigmakee.cvs.sourceforge.net/sigmakee/KBs/

Sigma classes are packaged into a jar for use as a library by the builder.
