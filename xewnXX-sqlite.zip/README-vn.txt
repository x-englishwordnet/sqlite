This includes
- the VerbNet 2.3 database mapped to WordNet 3.0 references
