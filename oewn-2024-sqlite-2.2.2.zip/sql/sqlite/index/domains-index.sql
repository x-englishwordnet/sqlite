CREATE UNIQUE INDEX `pk_domains` ON `domains` (`domainid`);
CREATE UNIQUE INDEX `uk_domains_domain_posid` ON `domains` (`domain`,`posid`);
