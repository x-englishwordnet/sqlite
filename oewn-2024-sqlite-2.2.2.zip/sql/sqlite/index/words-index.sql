CREATE UNIQUE INDEX `pk_words` ON `words` (`wordid`);
CREATE UNIQUE INDEX `uk_words_word` ON `words` (`word`);
