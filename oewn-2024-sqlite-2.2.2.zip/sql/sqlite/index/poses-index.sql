CREATE UNIQUE INDEX `pk_poses` ON `poses` (`posid`);
