CREATE TABLE `words` (
`wordid` INT NOT NULL,
`word` VARCHAR(80) NOT NULL
)
;
