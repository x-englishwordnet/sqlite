CREATE TABLE `vtemplates` (
`templateid` INT NOT NULL,
`template` MEDIUMTEXT NOT NULL
)
;
