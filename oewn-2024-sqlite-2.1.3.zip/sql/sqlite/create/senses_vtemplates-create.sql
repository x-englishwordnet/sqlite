CREATE TABLE `senses_vtemplates` (
`synsetid` INT NOT NULL,
`luid` INT NOT NULL,
`wordid` INT NOT NULL,
`templateid` INT NOT NULL
);
