CREATE UNIQUE INDEX `pk_lexes_morphs` ON `lexes_morphs` (`morphid`,`luid`,`posid`);
CREATE INDEX `k_lexes_morphs_morphid` ON `lexes_morphs` (`morphid`);
CREATE INDEX `k_lexes_morphs_luid` ON `lexes_morphs` (`luid`);
CREATE INDEX `k_lexes_morphs_wordid` ON `lexes_morphs` (`wordid`);
