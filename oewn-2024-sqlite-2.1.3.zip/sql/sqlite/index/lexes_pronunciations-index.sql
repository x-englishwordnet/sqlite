CREATE INDEX `k_lexes_pronunciations_pronunciationid` ON `lexes_pronunciations` (`pronunciationid`);
CREATE INDEX `k_lexes_pronunciations_luid` ON `lexes_pronunciations` (`luid`);
CREATE INDEX `k_lexes_pronunciations_wordid` ON `lexes_pronunciations` (`wordid`);
