CREATE UNIQUE INDEX `pk_samples` ON `samples` (`synsetid`,`sampleid`);
CREATE INDEX `k_samples_synsetid` ON `samples` (`synsetid`);
