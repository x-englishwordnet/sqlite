CREATE UNIQUE INDEX `pk_vframes` ON `vframes` (`frameid`);
CREATE UNIQUE INDEX `uk_vframes_frame` ON `vframes` (`frame`);
