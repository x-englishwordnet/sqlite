CREATE UNIQUE INDEX `pk_morphs` ON `morphs` (`morphid`);
CREATE UNIQUE INDEX `uk_morphs_morph` ON `morphs` (`morph`);
