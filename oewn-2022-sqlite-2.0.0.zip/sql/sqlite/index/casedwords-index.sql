CREATE UNIQUE INDEX `pk_casedwords` ON `casedwords` (`casedwordid`);
CREATE UNIQUE INDEX `uk_casedwords_casedword` ON `casedwords` (`casedword`);
CREATE INDEX `k_casedwords_wordid` ON `casedwords` (`wordid`);
CREATE INDEX `k_casedwords_wordid_casedwordid` ON `casedwords` (`wordid`,`casedwordid`);
