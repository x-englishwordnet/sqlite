CREATE UNIQUE INDEX `pk_synsets` ON `synsets` (`synsetid`);
