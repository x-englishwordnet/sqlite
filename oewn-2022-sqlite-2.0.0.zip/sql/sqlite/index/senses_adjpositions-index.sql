CREATE INDEX `k_senses_adjpositions_synsetid` ON `senses_adjpositions` (`synsetid`);
CREATE INDEX `k_senses_adjpositions_luid` ON `senses_adjpositions` (`luid`);
CREATE INDEX `k_senses_adjpositions_wordid` ON `senses_adjpositions` (`wordid`);
