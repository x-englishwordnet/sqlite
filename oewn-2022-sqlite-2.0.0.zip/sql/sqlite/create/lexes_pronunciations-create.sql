CREATE TABLE `lexes_pronunciations` (
`luid` INT NOT NULL,
`wordid` INT NOT NULL,
`posid` CHARACTER (1) CHECK( `posid` IN ('n','v','a','r','s') ) NOT NULL,
`pronunciationid` INT NOT NULL,
`variety` VARCHAR(2) DEFAULT NULL
);
