CREATE TABLE `domains` (
`domainid` INT NOT NULL,
`domain` VARCHAR(32) NOT NULL,
`domainname` VARCHAR(32) NOT NULL,
`posid` CHARACTER (1) CHECK( `posid` IN ('n','v','a','r','s') ) NOT NULL
)
;
