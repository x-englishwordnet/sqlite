CREATE TABLE `lexrelations` (
`synset1id` INT NOT NULL,
`lu1id` INT NOT NULL,
`word1id` INT NOT NULL,
`synset2id` INT NOT NULL,
`lu2id` INT NOT NULL,
`word2id` INT NOT NULL,
`relationid` INT NOT NULL
);
