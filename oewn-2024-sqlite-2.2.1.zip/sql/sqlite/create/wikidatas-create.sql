CREATE TABLE `wikidatas` (
`wikidata` VARCHAR(8) NOT NULL,
`synsetid` INT NOT NULL
)
;
