CREATE TABLE `senses_adjpositions` (
`synsetid` INT NOT NULL,
`luid` INT NOT NULL,
`wordid` INT NOT NULL,
`positionid` CHARACTER (1) CHECK( `positionid` IN ('a','p','ip') ) NOT NULL
);
