CREATE TABLE `ilis` (
`ili` VARCHAR(7) NOT NULL,
`synsetid` INT NOT NULL
)
;
