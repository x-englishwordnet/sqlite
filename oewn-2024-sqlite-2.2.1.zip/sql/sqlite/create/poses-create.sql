CREATE TABLE `poses` (
`posid` CHARACTER (1) CHECK( `posid` IN ('n','v','a','r','s') ) NOT NULL,
`pos` VARCHAR(20) NOT NULL
)
;
