INSERT INTO adjpositions (positionid,position) VALUES
('a','attributive'),
('ip','immediately postnominal'),
('p','predicate');
