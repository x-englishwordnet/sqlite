CREATE TABLE `relations` (
`relationid` INT NOT NULL,
`relation` VARCHAR(50) NOT NULL,
`recurses` TINYINT(1) NOT NULL
)
;
