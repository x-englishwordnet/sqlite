CREATE TABLE `samples` (
`sampleid` INT NOT NULL,
`sample` MEDIUMTEXT NOT NULL,
`source` MEDIUMTEXT NULL,
`synsetid` INT NOT NULL,
`luid` INT DEFAULT NULL,
`wordid` INT DEFAULT NULL
)
;
