CREATE TABLE `pronunciations` (
`pronunciationid` INT NOT NULL,
`pronunciation` VARCHAR(50) NOT NULL
)
;
