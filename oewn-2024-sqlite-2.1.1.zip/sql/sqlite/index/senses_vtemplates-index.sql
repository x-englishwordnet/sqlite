CREATE INDEX `k_senses_vtemplates_templateid` ON `senses_vtemplates` (`templateid`);
CREATE INDEX `k_senses_vtemplates_synsetid` ON `senses_vtemplates` (`synsetid`);
CREATE INDEX `k_senses_vtemplates_luid` ON `senses_vtemplates` (`luid`);
CREATE INDEX `k_senses_vtemplates_wordid` ON `senses_vtemplates` (`wordid`);
