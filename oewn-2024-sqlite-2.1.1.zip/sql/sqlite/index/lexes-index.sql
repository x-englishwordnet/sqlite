CREATE UNIQUE INDEX `pk_lexes` ON `lexes` (`luid`);
CREATE INDEX `k_lexes_wordid` ON `lexes` (`wordid`);
CREATE INDEX `k_lexes_casedwordid` ON `lexes` (`casedwordid`);
