CREATE INDEX `k_senses_vframes_frameid` ON `senses_vframes` (`frameid`);
CREATE INDEX `k_senses_vframes_synsetid` ON `senses_vframes` (`synsetid`);
CREATE INDEX `k_senses_vframes_luid` ON `senses_vframes` (`luid`);
CREATE INDEX `k_senses_vframes_wordid` ON `senses_vframes` (`wordid`);
