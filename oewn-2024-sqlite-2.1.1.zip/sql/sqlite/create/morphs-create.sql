CREATE TABLE `morphs` (
`morphid` INT NOT NULL,
`morph` VARCHAR(70) NOT NULL
)
;
