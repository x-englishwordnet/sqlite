CREATE TABLE `adjpositions` (
`positionid` CHARACTER (1) CHECK( `positionid` IN ('a','p','ip') ) NOT NULL,
`position` VARCHAR(24) NOT NULL
)
;
