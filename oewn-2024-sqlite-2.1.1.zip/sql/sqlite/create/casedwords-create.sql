CREATE TABLE `casedwords` (
`casedwordid` INT NOT NULL,
`wordid` INT NOT NULL ,
`casedword` VARCHAR(80) NOT NULL
)
;
