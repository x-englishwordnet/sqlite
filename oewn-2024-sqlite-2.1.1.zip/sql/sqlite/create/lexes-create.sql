CREATE TABLE `lexes` (
`luid` INT NOT NULL,
`posid` CHARACTER (1) CHECK( `posid` IN ('n','v','a','r','s') ) NOT NULL,
`wordid` INT NOT NULL,
`casedwordid` INT NULL
);
